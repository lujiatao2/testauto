"""
testauto示例代码
"""
