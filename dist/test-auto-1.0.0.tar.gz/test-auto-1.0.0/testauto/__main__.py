"""
提供给命令行使用，示例：
python -m testauto -h
"""
from .core import CommandLine

CommandLine()
