# getting_started.py
from testauto import main
from testauto.case import TestCase


class FirstTestCase(TestCase):

    def test_case(self):
        pass


if __name__ == '__main__':
    main()
