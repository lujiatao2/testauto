"""
提供给IDE使用，示例：
from testauto import main

if __name__ == '__main__':
    main()

"""
from .core import TestAuto

main = TestAuto
